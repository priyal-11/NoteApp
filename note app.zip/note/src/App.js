import React, { useState, useEffect } from 'react';
import './App.css';
import lottie from 'lottie-web';  // Import Lottie for animation

function App() {
  const [notes, setNotes] = useState([]); // Stores the notes
  const [input, setInput] = useState(''); // Input field value
  const [isEditing, setIsEditing] = useState(false); // Whether we are editing a note
  const [currentIndex, setCurrentIndex] = useState(null); // Index of note being edited
  const maxCharLimit = 100; // Define max character limit

  // Handles input change
  const handleInputChange = (e) => {
    setInput(e.target.value);
  };

  // Adds or updates a note
  const handleAddNote = () => {
    if (input.trim() && input.length <= maxCharLimit) {
      if (isEditing) {
        const updatedNotes = [...notes];
        updatedNotes[currentIndex] = input.trim();
        setNotes(updatedNotes);
        setIsEditing(false);
        setCurrentIndex(null);
      } else {
        setNotes([...notes, input.trim()]);
      }
      setInput('');
    }
  };

  // Deletes a note by index
  const handleDeleteNote = (index) => {
    const newNotes = notes.filter((note, i) => i !== index);
    setNotes(newNotes);
    
    if (isEditing && currentIndex === index) {
      setInput('');
      setIsEditing(false);
      setCurrentIndex(null);
    }
  };

  // Edits a note by index
  const handleEditNote = (index) => {
    setInput(notes[index]);
    setIsEditing(true);
    setCurrentIndex(index);
  };

  // Use Lottie animation for the header
  useEffect(() => {
    lottie.loadAnimation({
      container: document.getElementById('lottie-icon'), // The element to render the animation in
      renderer: 'svg',
      loop: true,
      autoplay: true,
      path: 'https://assets7.lottiefiles.com/packages/lf20_iqgfwwnm.json' // Example URL to a notebook icon animation
    });
  }, []);

  return (
    <div className="App">
      <h1>
        MY NOTES
        {/* Icon from Icons8 */}
        <img 
          src="https://img.icons8.com/officel/80/making-notes.png" // Replace with your actual CDN link
          alt="Notes Icon"
          style={{ width: '50px', height: '50px', marginLeft: '10px' }} // Adjust size and spacing as needed
        />
      </h1>


      {/* Input field and button */}
      <div className="input-container">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Type your note here"
          maxLength={maxCharLimit}
        />
        <button 
          onClick={handleAddNote} 
          disabled={input.trim() === '' || input.length > maxCharLimit}
        >
          {isEditing ? 'Update Note' : 'Add Note'}
        </button>
      </div>

      {/* Character count display */}
      <p className="char-count">
        {input.length}/{maxCharLimit} characters
      </p>

      {/* Notes list */}
      <div className="notes-container">
        {notes.length === 0 ? (
          <p>No notes yet</p>
        ) : (
          notes.map((note, index) => (
            <div className="note-card" key={index}>
              <div className="note-actions">
                <i className="fas fa-edit" onClick={() => handleEditNote(index)}></i>
                <i className="fas fa-trash-alt" onClick={() => handleDeleteNote(index)}></i>
              </div>
              <p className="note-content">{note}</p>
              <div className="note-footer">
                <p className="char-count-display">{note.length}/{maxCharLimit}</p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default App;
